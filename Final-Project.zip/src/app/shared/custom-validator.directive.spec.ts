import { CustomValidatorDirective } from './custom-validator.directive';

describe('CustomValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
