package com.example.angular;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularPeaceProjectBackEndApplication {

    public static void main(String[] args) {
        SpringApplication.run(AngularPeaceProjectBackEndApplication.class, args);
    }

}
