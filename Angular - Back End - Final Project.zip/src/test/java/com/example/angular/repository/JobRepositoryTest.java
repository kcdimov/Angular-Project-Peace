package com.example.angular.repository;

import static org.junit.jupiter.api.Assertions.*;

class JobRepositoryTest {

}