export interface IJob {
  id: number,
  category: string,
  position: string,
  description: string
}
