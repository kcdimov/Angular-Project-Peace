


export interface IPost {
  id: number;
  postName: string;
  description: string;
  imageUrl: string;

  //themeId: ITheme;
}
