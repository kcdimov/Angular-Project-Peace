import {InjectionToken} from "@angular/core";

export const LocalStorage = new InjectionToken('LocalStorage');
